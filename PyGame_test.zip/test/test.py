import pygame
import numpy as np
from sys import exit
from random import randint, choice

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # WALKING animation
        player_walk1 = pygame.image.load('player/horseL1.png').convert_alpha()
        player_walk2 = pygame.image.load('player/horseL2.png').convert_alpha()
        player_walk3 = pygame.image.load('player/horseL3.png').convert_alpha()
        self.player_walk = [player_walk1, player_walk2, player_walk3]
        self.player_index = 0

        # JUMP animation    
        self.player_jump = pygame.image.load('player/horseL_stand1.png').convert_alpha()
        self.gravity = 0
        self.jump_sound = pygame.mixer.Sound('audio/squeak.wav')
        self.jump_sound.set_volume(0.25)

        # TURN animation

        
        self.image = self.player_walk[self.player_index]
        self.rect = self.image.get_rect(midbottom=(200,360))

        self.orientation = 'right'

        self.foreback = pygame.image.load('background/moonforeground.png').convert_alpha()
        self.foreback_rect = self.foreback.get_rect(midbottom=(300,360))

    def player_input(self):
        keys = pygame.key.get_pressed()
        
        # SINGLE JUMP
        #if keys[pygame.K_UP] and self.rect.bottom >=360:
        # DOUBLE JUMP
        if keys[pygame.K_UP]:
            if self.rect.bottom >0:
                self.gravity = -7
                self.jump_sound.play()
            if self.rect.bottom >200:
                self.gravity = -15
                self.jump_sound.play()

        if keys[pygame.K_RIGHT]:
            #self.rect.x += 7
            self.orientation = 'right'

        if keys[pygame.K_LEFT]:
            #self.rect.x -= 7
            self.orientation = 'left'
        

    def apply_gravity(self):
        self.gravity +=2
        self.rect.y += self.gravity
        if self.rect.bottom >= 360:
            self.rect.bottom = 360

    def animation_state(self):
        if self.rect.bottom < 360:
            self.image = self.player_jump
        else:
            self.player_index += 0.1
            if self.player_index > len(self.player_walk): self.player_index = 0
            self.image = self.player_walk[int(self.player_index)]

        if self.orientation == 'left':
            self.image = pygame.transform.flip(self.image,True,False)  

    def update(self):
        self.player_input()
        self.apply_gravity()
        self.animation_state()


class Obstacle(pygame.sprite.Sprite):
    def __init__(self,type):
        super().__init__()

        if type== 'brown_horse':
            horse1a = pygame.image.load('sprites/horse1a.png').convert_alpha()
            horse1b = pygame.image.load('sprites/horse1b.png').convert_alpha()
            self.frames = [horse1a,horse1b]
            x_pos = randint(800,1000)
            y_pos = randint(200,400)

        elif type== 'purple_horse':
            diaghorsea = pygame.image.load('sprites/horse4a.png').convert_alpha()
            diaghorseb = pygame.image.load('sprites/horse4b.png').convert_alpha()
            self.frames = [diaghorsea,diaghorseb]
            x_pos = randint(800,1000)
            y_pos = randint(350, 400)

        elif type== 'pink_horse':
            pinkhorsea = pygame.image.load('sprites/horse3a.png').convert_alpha()
            pinkhorseb = pygame.image.load('sprites/horse3b.png').convert_alpha()
            self.frames = [pinkhorsea,pinkhorseb]
            x_pos = randint(800,1000)
            y_pos = randint(100, 350)

        elif type== 'gray_horse':
            horse3a = pygame.image.load('sprites/horse6a.png').convert_alpha()
            horse3b = pygame.image.load('sprites/horse6b.png').convert_alpha()
            self.frames = [horse3a,horse3b]
            x_pos = randint(800,1000)
            y_pos = randint(150, 300)

        elif type== 'cervidae':
            cervidaea = pygame.image.load('sprites/cervidae/cervidae_sneer1.png').convert_alpha()
            cervidaeb = pygame.image.load('sprites/cervidae/cervidae_sneer2.png').convert_alpha()
            cervidaec = pygame.image.load('sprites/cervidae/cervidae_sneer3.png').convert_alpha()
            self.frames = [cervidaea,cervidaeb,cervidaec]
            x_pos = randint(150,200)
            y_pos = randint(130, 180)

        elif type== 'heart':
            hearta = pygame.image.load('sprites/heart.png').convert_alpha()
            #cervidaeb = pygame.image.load('sprites/cervidae2.png').convert_alpha()
            self.frames = [hearta]
            x_pos = randint(800,1000)
            y_pos = randint(0, 380)

        else:
            raru = pygame.image.load('sprites/unicorn.png').convert_alpha()
            #cervidaeb = pygame.image.load('sprites/cervidae2.png').convert_alpha()
            self.frames = [raru]
            x_pos = randint(150,200)
            y_pos = randint(300, 350)
            
        self.animation_index=0
        
        self.image = self.frames[self.animation_index]
        self.rect = self.image.get_rect(midbottom=(x_pos,y_pos))

        if type=='cervidae':
            self.c=-1
            self.animation_index += 0.05

        elif type=='heart':
            self.c=6
            self.animation_index += 0.1
        else:
            self.c=randint(1,4)
            self.animation_index += 0.1

    def animation_state(self):
        self.animation_index += 0.1
        if self.animation_index >= len(self.frames): self.animation_index = 0
        self.image = self.frames[int(self.animation_index)]
        self.rect.x -=self.c  
        
    def update(self):
        self.animation_state()

    def destroy(self):
        if self.rect.x < -100 or self.rect >1100:
            self.kill()


def collision_sprite():
    if pygame.sprite.spritecollide(player_sprite.sprite,obstacle_group_heart,False):
        obstacle_group_heart.empty()
        return True
    if pygame.sprite.spritecollide(player_sprite.sprite,obstacle_group_heart2,False):
        obstacle_group_heart2.empty()
        return True
    if pygame.sprite.spritecollide(player_sprite.sprite,obstacle_group_heart3,False):
        obstacle_group_heart3.empty()
        return True
    else:
        return False


def display_score():
    current_time = int((pygame.time.get_ticks() - start_time)/1000)
    score_surf = smaller_font.render(f'epochs: {current_time}', False, 'White').convert_alpha()
    score_surf_rect = score_surf.get_rect(topright=(790,10))
    screen.blit(score_surf,score_surf_rect)
    return current_time

def display_collision():
    current_collision = collision - last_colision
    collision_surf = small_font.render(f'love: {current_collision}', False, 'White').convert_alpha()
    collision_surf_rect = collision_surf.get_rect(topright=(790,20))
    screen.blit(collision_surf,collision_surf_rect)

    # scorebar
    heart_icon = pygame.image.load('sprites/heart.png').convert_alpha()
    heart_icon_rect = heart_icon.get_rect(midright=(30,30))
    screen.blit(heart_icon,heart_icon_rect)
    
    score_bar = pygame.draw.rect(screen,'Pink',pygame.Rect(30,30,current_collision*2,10))
    
    return current_collision

def obstacle_movement(obstacle_list,obstacle_number):
    things=[cervidae, horse1, horse2, horse3]
    if obstacle_list:
        for obstacle_rect in obstacle_list:
            obstacle_rect.x -= 5
            obstacle_rect.y -= sin(obstacle_rect.x)
            
            screen.blit(things[obstacle_number],obstacle_rect)

        obstacle_list = [obstacle for obstacle in obstacle_list if obstacle.x>-100]
        return obstacle_list
    else:
        return []

def collisions(player,obstacles):
    if obstacles:
        for obstacle_rect in obstacles:
            if player.colliderect(obstacle_rect):
                return False
                # if player collides, game is false
    return True



def checkHeldKeys():#use this in you'r game loop to move you'r character
    for i in heldKeys:
        if 'R' in heldKeys:
            test_surface_fore_rect.x -= 7
        if 'L' in heldKeys:
            test_surface_fore_rect.x += 7
            
pygame.init()
screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('ET Game')
clock = pygame.time.Clock()
test_font = pygame.font.Font('font/Pixeltype.ttf', 50)
small_font = pygame.font.Font('font/Pixeltype.ttf', 30)
smaller_font = pygame.font.Font('font/Pixeltype.ttf', 20)

game_active = False
start_time = 0
score = 0
max_score = 25

last_colision=0
collision=0

#### music
bg_music= pygame.mixer.Sound('audio/squeak.wav')
bg_music.set_volume(0.25)
#bg_music.play(loops = -1)
heart_sound = pygame.mixer.Sound('audio/heart.wav')

test_surface = pygame.image.load('background/moon_pixel_back.png').convert()
test_surface_fore = pygame.image.load('background/moon_pixel_foreback.png').convert_alpha()
test_surface_fore_rect = test_surface_fore.get_rect(center=(200,200))

####################
## TITTLIES
title_raru = test_font.render('RaRuRu', False, 'White').convert_alpha()
title_raru_rect = title_raru.get_rect(center=(400,50))

############
# buttons
zen_text = small_font.render('>Zen mode<', False, 'White').convert_alpha()
zen_text_rect = zen_text.get_rect(bottomleft=(10,380))

quickie_text = small_font.render('>quickie<', False, 'White').convert_alpha()
quickie_text_rect = quickie_text.get_rect(bottomleft=(10,395))


raru = pygame.image.load('player/unicorn.png').convert_alpha()
raru_rect = raru.get_rect(midbottom=(80,400))

horseL = pygame.image.load('sprites/horse7_L.png').convert_alpha()
horseL_rect = horseL.get_rect(midbottom=(100,400))

cervidaea = pygame.image.load('sprites/cervidae.png').convert_alpha()
cervidaeb = pygame.image.load('sprites/cervidae2.png').convert_alpha()
cervidae_frame = [cervidaea,cervidaeb]
cervidae_index=0
cervidae = cervidae_frame[cervidae_index]
cervidae_rect = cervidae.get_rect(midbottom=(100,200))

##########
# OBSTACLE SPRITE
obstacle_group_heart = pygame.sprite.Group()
obstacle_group_heart2 = pygame.sprite.Group()
obstacle_group_heart3 = pygame.sprite.Group()

obstacle_group1 = pygame.sprite.Group()
obstacle_group2 = pygame.sprite.Group()



###########
## PLAYER

player_sprite = pygame.sprite.GroupSingle()
player_sprite.add(Player())
player_grav = 0

### INTRO START SCREEN
# INTRO SCREEN stand
player_stand = pygame.image.load('player/horseL_stand2.png').convert_alpha()
player_stand = pygame.transform.rotozoom(player_stand,0,2)
player_stand_rect = player_stand.get_rect(center=(400,200))

heart_icon = pygame.image.load('sprites/heart.png').convert_alpha()
big_heart = pygame.transform.rotozoom(heart_icon,0,8)


## TITTLIES
game_name = test_font.render('RaRuRu', False, (250,235,241)).convert_alpha()
game_name_rect = game_name.get_rect(center=(400,50))

##MESSAHGE
end = test_font.render(f'Who is the rarest of them all???', False, 'White').convert_alpha()
end_rect = end.get_rect(center=(400,350))
end_heart=big_heart.get_rect(center=(400,200))
####

obstacle=1

## TIMER

# player timer
cervi_timer = pygame.USEREVENT +1
pygame.time.set_timer(cervi_timer,3000)

# frequent timer
frequent_timer = pygame.USEREVENT +2
pygame.time.set_timer(frequent_timer,1000)

# rare timer
rare_timer = pygame.USEREVENT +3
pygame.time.set_timer(rare_timer,50000)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

        if game_active:
            
            # buttons
            if event.type == pygame.MOUSEBUTTONUP: #MOUSEBUTTONUP
                if zen_text_rect.collidepoint(event.pos):
                    max_score=1000000
                    print('min love is....one MILLION!')
                    

            if event.type == pygame.MOUSEBUTTONUP: #MOUSEBUTTONUP
                if quickie_text_rect.collidepoint(event.pos):
                    max_score=4
                    print('min love is 5')

            keys = pygame.key.get_pressed()
            heldKeys=[]

            if event.type == pygame.KEYDOWN:

                if keys[pygame.K_RIGHT]:
                    heldKeys.append('R')
                    test_surface_fore_rect.x -= 7

                if keys[pygame.K_LEFT]:
                    heldKeys.append('L')
                    test_surface_fore_rect.x += 7

            elif event.type == pygame.KEYUP:#Track down key releases here
                if keys[pygame.K_DOWN]:
                    heldKeys.clear()

        else:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                raru_rect.left = 700
                game_active = True
                collision = 0
                start_time = pygame.time.get_ticks()
                last_collision = collision

        # using the timers for animation        
        if game_active:
            if event.type == cervi_timer:

                #obstacle_group_heart.add(Obstacle(choice(['heart'])))
                #obstacle_group_heart2.add(Obstacle(choice(['heart'])))

                obstacle_group2.add(Obstacle(choice(['pink_horse','purple_horse', 'brown_horse'])))

            if event.type == frequent_timer:

                obstacle_group_heart.add(Obstacle(choice(['heart'])))
                obstacle_group_heart2.add(Obstacle(choice(['heart'])))

                #obstacle_group1.add(Obstacle(choice(['cervidae'])))
                #obstacle_group2.add(Obstacle(choice(['pink_horse','purple_horse', 'brown_horse'])))

            if event.type == rare_timer:

                obstacle_group_heart.add(Obstacle(choice(['heart'])))
                obstacle_group_heart2.add(Obstacle(choice(['heart'])))

                obstacle_group1.add(Obstacle(choice(['cervidae'])))
  
    if game_active:
        
        screen.blit(test_surface,(0,-70))
        screen.blit(title_raru,title_raru_rect)


        #### SPRITES

        #OBSTACLE SPRITE
        obstacle_group_heart.draw(screen)
        obstacle_group_heart.update()
        obstacle_group_heart2.draw(screen)
        obstacle_group_heart2.update()
        obstacle_group_heart3.draw(screen)
        obstacle_group_heart3.update()


        player_sprite.draw(screen)
        player_sprite.update()

        obstacle_group1.draw(screen)
        obstacle_group1.update()
        
        obstacle_group2.draw(screen)
        obstacle_group2.update()

        # place forground

        
        screen.blit(test_surface_fore,test_surface_fore_rect)
        checkHeldKeys()

        if collision_sprite():
            collision += 1
            if collision > max_score:
                #end = test_font.render(f'LOVE', False, 'White').convert_alpha()
                game_active = False
            
            heart_sound.play()
            print('+1')

        # buttons
        pygame.draw.rect(screen,(64,64,64),zen_text_rect)
        screen.blit(zen_text,zen_text_rect)
        
        pygame.draw.rect(screen,(64,64,64),quickie_text_rect)
        screen.blit(quickie_text,quickie_text_rect)
        # end buttons

        score = display_score()
        collision = display_collision()


    else:
        screen.fill((94,129,162))
        
        score_message = small_font.render(f'{score} epochs have passed until you found love',False,'white')
        score_message_rect = score_message.get_rect(center=(400,300))

        #collide_count = small_font.render(f'{collision} collisions!',False,'white')
        #collide_count_rect = score_message.get_rect(center=(400,300))

        
        if score == 0:
            screen.blit(end,end_rect)
            screen.blit(player_stand,player_stand_rect)
        else:
            screen.blit(big_heart,end_heart)
            screen.blit(end,end_rect)
            screen.blit(score_message,score_message_rect)
            screen.blit(player_stand,player_stand_rect)
        
        screen.blit(game_name,game_name_rect)
        
    pygame.display.update()
    clock.tick(60)

