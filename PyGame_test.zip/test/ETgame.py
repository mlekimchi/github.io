import pygame
import numpy as np
from sys import exit
from random import randint

def display_score():
    current_time = int((pygame.time.get_ticks() - start_time)/1000)
    score_surf = smaller_font.render(f'{current_time}', False, 'White').convert_alpha()
    score_surf_rect = score_surf.get_rect(topright=(790,10))
    screen.blit(score_surf,score_surf_rect)
    return current_time

def display_collision():
    current_collision = collision - last_colision
    collision_surf = small_font.render(f'collisions: {current_collision}', False, 'White').convert_alpha()
    collision_surf_rect = collision_surf.get_rect(topright=(790,20))
    screen.blit(collision_surf,collision_surf_rect)
    return current_collision

def obstacle_movement(obstacle_list,obstacle_number):
    things=[cervidae, horse1, horse2, horse3]
    if obstacle_list:
        for obstacle_rect in obstacle_list:
            obstacle_rect.x -= 5
            
            screen.blit(things[obstacle_number],obstacle_rect)

        obstacle_list = [obstacle for obstacle in obstacle_list if obstacle.x>-100]
        return obstacle_list
    else:
        return []

def collisions(player,obstacles):
    if obstacles:
        for obstacle_rect in obstacles:
            if player.colliderect(obstacle_rect):
                return False
                # if player collides, game is false
    return True
                

def player_animation():
    # walk when on floow
    # jump when NOT on floor!

    global player, player_index

    if player_rect.bottom < 360: #jump
        player = player_jump

    else:
        player_index += 0.05
        if player_index>len(player_walk): player_index=0
        player = player_walk[int(player_index)]

pygame.init()
screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('ET Game')
clock = pygame.time.Clock()
test_font = pygame.font.Font('font/Pixeltype.ttf', 50)
small_font = pygame.font.Font('font/Pixeltype.ttf', 30)
smaller_font = pygame.font.Font('font/Pixeltype.ttf', 20)

game_active = False
start_time = 0
score = 0

last_colision=0
collision=0

cont = True

#test_surface = pygame.Surface((800,50)) #pygame.Surface((width,height))
#test_surface.fill()
#test_surface = pygame.image.load('background/library.png')
    #screen.blit(test_surface,(0,-150))
#test_surface = pygame.image.load('background/library2.png')
    #screen.blit(test_surface,(-100,-150))

test_surface = pygame.image.load('background/moon.png').convert()
test_surface_fore = pygame.image.load('background/moonforeground.png').convert_alpha()

####################
## TITTLIES
title_raru = test_font.render('RaRuRu', False, 'White').convert_alpha()
title_raru_rect = title_raru.get_rect(center=(400,50))

############
# buttons
good_text = small_font.render('>I love unicorns <3', False, 'White').convert_alpha()
good_text_rect = good_text.get_rect(bottomleft=(10,380))

bad_text = small_font.render('>I hate unicorns >:(', False, 'White').convert_alpha()
bad_text_rect = bad_text.get_rect(bottomleft=(10,395))
# end buttoms
##############


### OBSTACLES
#animated horse 1
horse1a = pygame.image.load('sprites/horse1a.png').convert_alpha()
horse1b = pygame.image.load('sprites/horse1b.png').convert_alpha()
horse1_frame = [horse1a,horse1b]
horse1_index=0
horse1 = horse1_frame[horse1_index]
horse1_rect = horse1.get_rect(midbottom=(800,230))

horse2 = pygame.image.load('sprites/horse2.png').convert_alpha()
horse2_rect = horse2.get_rect(midbottom=(400,400))

#animated horse 3
horse3a = pygame.image.load('sprites/horse4a.png').convert_alpha()
horse3b = pygame.image.load('sprites/horse4b.png').convert_alpha()
horse3_frame = [horse3a,horse3b]
horse3_index=0
horse3 = horse3_frame[horse3_index]
horse3_rect = horse3.get_rect(midbottom=(600,400))

horse4 = pygame.image.load('sprites/horse3.png').convert_alpha()
horse4_rect = horse4.get_rect(midbottom=(400,400))

horse6 = pygame.image.load('sprites/horse6.png').convert_alpha()
horse6_rect = horse6.get_rect(midbottom=(600,300))

raru = pygame.image.load('player/unicorn.png').convert_alpha()
raru_rect = raru.get_rect(midbottom=(80,400))

horseL = pygame.image.load('sprites/horse7_L.png').convert_alpha()
horseL_rect = horseL.get_rect(midbottom=(100,400))

#cervidae = pygame.image.load('sprites/cervidae.png').convert_alpha()
#cervidae_rect = cervidae.get_rect(midbottom=(100,400))

cervidaea = pygame.image.load('sprites/cervidae.png').convert_alpha()
cervidaeb = pygame.image.load('sprites/cervidae2.png').convert_alpha()
cervidae_frame = [cervidaea,cervidaeb]
cervidae_index=0
cervidae = cervidae_frame[cervidae_index]
cervidae_rect = cervidae.get_rect(midbottom=(100,200))



obstacle_list=[]

###########
## PLAYER
player_walk1 = pygame.image.load('player/horseL1.png').convert_alpha()
player_walk2 = pygame.image.load('player/horseL2.png').convert_alpha()
player_walk3 = pygame.image.load('player/horseL3.png').convert_alpha()
player_jump = pygame.image.load('player/horseL_stand1.png').convert_alpha()

player_walk = [player_walk1, player_walk2, player_walk3]
player_index = 0
player = player_walk[1]

player_rect = player.get_rect(midbottom=(100,360))
player_grav = 0

### INTRO START SCREEN
# INTRO SCREEN stand
player_stand = pygame.image.load('player/horseL_stand2.png').convert_alpha()
player_stand = pygame.transform.rotozoom(player_stand,0,2)
player_stand_rect = player_stand.get_rect(center=(400,200))


## TITTLIES
game_name = test_font.render('RaRuRu', False, (250,235,241)).convert_alpha()
game_name_rect = game_name.get_rect(center=(400,50))

##MESSAHGE
end = test_font.render(f'Who is the rarest of them all???', False, 'White').convert_alpha()
end_rect = end.get_rect(center=(400,350))
####

obstacle=1

## TIMER

# player timer
cervi_timer = pygame.USEREVENT +1
pygame.time.set_timer(cervi_timer,3000)

# horse 1 animation time4
horse1_animation_time = pygame.USEREVENT +2
pygame.time.set_timer(horse1_animation_time,500)

# horse 3 animation timer
horse3_animation_time = pygame.USEREVENT +3
pygame.time.set_timer(horse3_animation_time,300)

# cervidae animation timer
cervidae_animation_time = pygame.USEREVENT +4
pygame.time.set_timer(cervidae_animation_time,500)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

        if game_active:
            
            if event.type == pygame.MOUSEBUTTONDOWN: #MOUSEBUTTONUP
                if player_rect.collidepoint(event.pos):
                    player_grav = -20

            # buttons
            if event.type == pygame.MOUSEBUTTONUP: #MOUSEBUTTONUP
                if good_text_rect.collidepoint(event.pos):print('YAY!')

            if event.type == pygame.MOUSEBUTTONUP: #MOUSEBUTTONUP
                if bad_text_rect.collidepoint(event.pos):print('then shoot them >:)')
            # end buttons

            if event.type == pygame.KEYDOWN:
                #keys = pygame.key.get_pressed()
                if event.key == pygame.K_SPACE and player_rect.bottom > 0:
                    player_grav = -20
                    #print('jump!')

        else:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                raru_rect.left = 700
                game_active = True
                start_time = pygame.time.get_ticks()
                last_collision = collision

        # using the timers for animation        
        if game_active:
            if event.type == cervi_timer:
                rand_ob = randint(0,10)
                if rand_ob<=3:
                    obstacle_list.append(cervidae.get_rect(bottomright=(randint(900,1100),randint(380,550))))
                    obstacle=0
                elif rand_ob<=4:
                    obstacle_list.append(horse1.get_rect(bottomright=(randint(900,1100),randint(200,250))))
                    obstacle=1
                elif rand_ob<=8:
                    obstacle_list.append(horse2.get_rect(bottomright=(randint(900,1100),randint(120,200))))
                    obstacle=2
                else:
                    obstacle_list.append(horse3.get_rect(bottomright=(randint(900,1100),randint(300,400))))
                    obstacle=3

            if event.type == horse1_animation_time:
                if horse1_index == 0:
                    horse1_index = 1
                else:
                    horse1_index = 0
                horse1 = horse1_frame[horse1_index]

            if event.type == horse3_animation_time:
                if horse3_index == 0:
                    horse3_index = 1
                else:
                    horse3_index = 0
                horse3 = horse3_frame[horse3_index]

            if event.type == cervidae_animation_time:
                if cervidae_index == 0:
                    cervidae_index = 1
                else:
                    cervidae_index = 0
                cervidae = cervidae_frame[cervidae_index]


                
    if game_active:
        #screen.blit(surface,position)
                #position (0,0) origin is (left-right,top-bottom)
        screen.blit(test_surface,(0,0))

        screen.blit(title_raru,title_raru_rect)

        # draw a rectangle with
        #   pygame.draw
        #display surface, color, rectangle 
        #pygame.draw.rect(screen,'Pink',score_surf_rect)
        #pygame.draw.ellipse(screen,'Gold',pygame.Rect(50,200,100,100))

        if horse1_rect.left==-100:
            horse1_rect.left=800

        if horse2_rect.left==-100:
            horse2_rect.left=800

        if horse3_rect.top==-100:
            horse3_rect.left=800
            horse3_rect.bottom=400

        if  horse4_rect.left==-100:
            horse4_rect.left=800

        if  horse6_rect.left==-100:
            horse6_rect.left=800
        
        if  raru_rect.left==900:
            raru_rect.left=0

        if  horseL_rect.left==900:
            horseL_rect.left=0

    # POSITION HORSES
        horse1_rect.left -=1
        horse2_rect.left -= 2
        horse3_rect.left -= 5
        horse3_rect.bottom -= np.exp(0.5)
        horse4_rect.left -= 3
        horse6_rect.left -=1
        raru_rect.left +=1
        horseL_rect.left +=2
        cervidae_rect.left -=1
        
        screen.blit(horse1,horse1_rect)
        screen.blit(horse3,horse3_rect)
        
        screen.blit(raru,raru_rect)
        screen.blit(horseL,horseL_rect)
        screen.blit(cervidae,cervidae_rect)

        #print(player_rect)

        # place forground
        screen.blit(test_surface_fore,(0,0))


        screen.blit(horse2,horse2_rect)
        screen.blit(horse4,horse4_rect)
        screen.blit(horse6,horse6_rect)
        
        #if player_rect.colliderect(raru_rect):
        #    collision+=1
        #    print(collision)


        # mouse hover! mouse collide!
        #mouse_pos = pygame.mouse.get_pos()
        #if horse1_rect.collidepoint(mouse_pos):
            #print(pygame.mouse.get_pressed()) #(right,mid,left)
        #    print('horse 1')


        ## PLAYER
        player_grav += 1
        player_rect.y += player_grav

        if  player_rect.bottom > 360:
             player_rect.bottom = 360

        player_animation()
        screen.blit(player,player_rect)

        obstacle_list = obstacle_movement(obstacle_list,obstacle)
            

        if horse3_rect.colliderect(player_rect):
            print('Collision in airspace!')
            #end = small_font.render(f'sky collision!', False, 'White').convert_alpha()
            horse3_rect.left=800
            horse3_rect.bottom=400
            collision += 1
            if collision >5:
                end = small_font.render(f'sky collision!', False, 'White').convert_alpha()
                print('horse3')
                game_active = False
            
        #if horse1_rect.colliderect(player_rect):
        #    print('boop!')
        #    horse1_rect.left=800
        #    end = small_font.render(f'BOOP!', False, 'White').convert_alpha()
        #    collision += 1
        #    print('horse1')
            #if collision > 5:
            #    game_active = False

        if cervidae_rect.colliderect(player_rect):
            print('gross, cervidae touched you....')
            cervidae_rect.left=800
            end = small_font.render(f'ewww, you touched cervidae...', False, 'White').convert_alpha()
            collision += 1

#        mouse_pos = pygame.mouse.get_pos()
#        if raru_rect.collidepoint(mouse_pos):
#            #print(pygame.mouse.get_pressed()) #(right,mid,left)
#            end = small_font.render(f'Bang! you shot the unicorn! \nThat was the last one, how could you???!', False, 'White').convert_alpha()
#            raru_rect.left=0
#            game_active = False


        # buttons
        pygame.draw.rect(screen,(64,64,64),good_text_rect)
        screen.blit(good_text,good_text_rect)
        
        pygame.draw.rect(screen,(64,64,64),bad_text_rect)
        screen.blit(bad_text,bad_text_rect)
        # end buttons

        score = display_score()
        collision = display_collision()

        game_active = collisions(player_rect, obstacle_list)

    else:
        screen.fill((94,129,162))
        screen.blit(player_stand,player_stand_rect)
        
        score_message = small_font.render(f'{score} epochs have passed',False,'white')
        score_message_rect = score_message.get_rect(center=(400,330))

        collide_count = small_font.render(f'{collision} collisions!',False,'white')
        collide_count_rect = score_message.get_rect(center=(400,300))

        
        obstacle_list=[]

        
        
        if score == 0:
            screen.blit(end,end_rect)
        else:
            screen.blit(end,end_rect)
            #screen.blit(score_message,score_message_rect)
            screen.blit(collide_count,collide_count_rect)
        
        screen.blit(game_name,game_name_rect)
        
    pygame.display.update()
    clock.tick(60)

